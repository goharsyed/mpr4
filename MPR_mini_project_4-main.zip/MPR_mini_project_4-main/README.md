# MPR Mini Project 
## Topic 4
This is the mini project required by the course "Mobile Programming" by lecturer Nguyen Xuan Thang. In this project, I will develop a simple React Native Game App called Expression Building game.
